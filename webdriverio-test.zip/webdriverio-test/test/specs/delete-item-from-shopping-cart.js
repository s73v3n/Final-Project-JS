describe('Deleting A Product', () => {

    it('should delete item from shopping cart', async () => {  //npx wdio --spec ./test/specs/delete-item-from-shopping-cart.js
        await browser.url('http://automationpractice.com/index.php'); 

        await browser.maximizeWindow();

        await expect(browser).toHaveTitle('My Store');

        await $('=Sign in').click();

        await expect(browser).toHaveTitle('Login - My Store');

        await $('#email').setValue('jonathan.forrest2@mail.com');

        await $('#passwd').setValue('Jonathan123');

        await $('#SubmitLogin').click();

        await expect(browser).toHaveTitle('My account - My Store');

        await $('=Home').click();

        await $('=Printed Chiffon Dress').click();

        await expect(browser).toHaveTitle('Printed Chiffon Dress - My Store');

        await $('#color_15').click();

        await $('[name="Submit"]').click();

        await $('=Proceed to checkout').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('[class="cart_quantity_delete"]').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('[class="logout"]').click();

        await browser.pause(5000);

    })
})