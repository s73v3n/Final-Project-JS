describe('Purchasing A Product', () => {

    it('should complete order', async () => {  //npx wdio --spec ./test/specs/complete-order.js
        await browser.url('http://automationpractice.com/index.php'); 

        await browser.maximizeWindow();

        await expect(browser).toHaveTitle('My Store');
        
        await $('=Sign in').click();

        await expect(browser).toHaveTitle('Login - My Store');

        await $('#email').setValue('jonathan.forrest2@mail.com');

        await $('#passwd').setValue('Jonathan123');

        await $('#SubmitLogin').click();

        await expect(browser).toHaveTitle('My account - My Store');

        await $('=Home').click();

        await $('=Blouse').click();

        await expect(browser).toHaveTitle('Blouse - My Store');

        await $('#color_8').click();

        await $('[name="Submit"]').click();

        await $('=Proceed to checkout').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('=Proceed to checkout').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('[name="message"]').setValue('Contact me on my phone for delivery time');

        await $('[name="processAddress"]').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('#cgv').click();

        await $('[name="processCarrier"]').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('[class="bankwire"]').click();

        await expect(browser).toHaveTitle('My Store');

        await $('[class="button btn btn-default button-medium"]').click();

        await expect(browser).toHaveTitle('Order confirmation - My Store');

        await $('[class="logout"]').click();

        await browser.pause(5000);

    })
})