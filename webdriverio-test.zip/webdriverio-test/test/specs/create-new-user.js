describe('Create New User', () => {

    it('should register a new user', async () => {  //npx wdio --spec ./test/specs/create-new-user.js
        await browser.url('http://automationpractice.com/index.php');
       
        await browser.maximizeWindow();
        
        await $('=Sign in').click();

        await expect(browser).toHaveTitle('Login - My Store');
        
        await $('#email_create').setValue('jonathan.forrest@mail.com');
        
        await $('#SubmitCreate').click();
        
        await $('#id_gender1').click();

        await $('#customer_firstname').setValue('Jonathan');

        await $('#customer_lastname').setValue('Forrest');

        await $('#passwd').setValue('Jonathan123');

        const days = await $('#days');
        console.log(await days.getValue());
        await days.selectByIndex(15);
        console.log(await days.getValue());

        const months = await $('#months');
        console.log(await months.getValue());
        await months.selectByIndex(5);
        console.log(await months.getValue());

        const years = await $('#years');
        console.log(await years.getValue());
        await years.selectByIndex(35);
        console.log(await years.getValue());

        await $('#newsletter').click();

        await $('#optin').click();

        await $('#company').setValue('Jack Daniel Distillery');

        await $('#address1').setValue('133 Lynchburg Hwy');

        await $('#address2').setValue('Unit 89');

        await $('#city').setValue('Lynchburg');

        const state = await $('#id_state');
        console.log(await state.getValue());
        await state.selectByIndex(44);
        console.log(await state.getValue());

        await $('#postcode').setValue('37352');

        await $('#other').setValue('Phone calls between 18:00 and 20:00');

        await $('#phone').setValue('+1 123 456 7890');

        await $('#phone_mobile').setValue('+1 098 765 4321');

        await $('#alias').setValue('280 Lynchburg Hwy');

        await browser.pause(5000);

        await $('#submitAccount').click();

        await browser.pause(5000);

        await expect(browser).toHaveTitle('My account - My Store');

        await $('[class="logout"]').click();

        await browser.pause(5000);
    });
})