describe('Adding Products To Shopping Cart', () => {

    it('should add products to shopping cart', async () => {  //npx wdio --spec ./test/specs/adding-products-to-shopping-cart.js
        await browser.url('http://automationpractice.com/index.php'); 

        await browser.maximizeWindow();

        await $('#search_query_top').setValue('casual');

        await $('[name="submit_search"]').click();

        await expect(browser).toHaveTitle('Search - My Store');

        await $('=Printed Summer Dress').click();

        await expect(browser).toHaveTitle('Printed Summer Dress - My Store');

        await $('i.icon-plus').click();

        const size1 = await $('#group_1');
        console.log(await size1.getValue());
        await size1.selectByIndex(2);
        console.log(await size1.getValue());

        await $('#color_14').click();

        await $('#add_to_cart').click();

        await $('=Proceed to checkout').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('=Continue shopping').click();

        await $('#search_query_top').setValue('casual');

        await $('[name="submit_search"]').click();

        await $('=Faded Short Sleeve T-shirts').click();

        await expect(browser).toHaveTitle('Faded Short Sleeve T-shirts - My Store');

        await $('i.icon-plus').click();

        await $('i.icon-plus').click();

        const size2 = await $('#group_1');
        console.log(await size2.getValue());
        await size2.selectByIndex(1);
        console.log(await size2.getValue());

        await $('[name="Blue"]').click();

        await $('[name="Submit"]').click();

        await $('=Proceed to checkout').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await $('=Continue shopping').click();

        await $('#search_query_top').setValue('casual');

        await $('[name="submit_search"]').click();

        await $('=Blouse').click();

        await expect(browser).toHaveTitle('Blouse - My Store');

        await $('i.icon-plus').click();

        await $('i.icon-minus').click();

        const size3 = await $('#group_1');
        console.log(await size3.getValue());
        await size3.selectByIndex(2);
        console.log(await size3.getValue());

        await $('[name="White"]').click();

        await $('[name="Submit"]').click();

        await $('=Proceed to checkout').click();

        await expect(browser).toHaveTitle('Order - My Store');

        await browser.pause(5000);
    });
    });